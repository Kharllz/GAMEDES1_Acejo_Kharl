extends Node

var scenes = [
	"res://scene1.tscn",
	"res://scene2.tscn",
	"res://scene3.tscn",
	"res://scene4.tscn",
	"res://scene5.tscn"
]
var current_index = 0

func go_next():
	current_index = min(current_index + 1, scenes.size() - 1)
	get_tree().change_scene_to_file(scenes[current_index])

func go_previous():
	current_index = max(current_index - 1, 0)
	get_tree().change_scene_to_file(scenes[current_index])
